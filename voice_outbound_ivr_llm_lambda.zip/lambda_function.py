import json
import boto3
import os

bedrock = boto3.client(service_name="bedrock-runtime")

def get_chat_response_3(prompt):
    text = ''
    system_prompt = os.environ['Prompt']

    if prompt:
        body = json.dumps({
            "system": system_prompt,
            "temperature": 0.1,
            "max_tokens": 4096,
            "messages": [{"role": "user", "content": prompt}],
            "anthropic_version": "bedrock-2023-05-31"
        })
    
        try:
            response = bedrock.invoke_model(
                body=body, modelId="anthropic.claude-3-haiku-20240307-v1:0")

            response_text = json.loads(response.get("body").read())
            text = response_text["content"][0]["text"]
        except Exception as e:
            # Handle the exception
            print(f"An exception occurred: {e}")
    
    return text

    
def get_ssml_text(answer_text):
    answer_text = answer_text.replace("Got it","<say-as interpret-as=\"verbal\">Got it</say-as>")
    answer_text = answer_text.replace("...","<break time=\"1s\"/>")
    return "<speak><prosody rate=\"90%\">" + answer_text + "</prosody></speak>"

def Claude3Search_AWS_SSML(intent_request):
    session_attributes = get_session_attributes(intent_request)
    input_text = get_prompt(intent_request)
    input_text_lower = input_text.lower()
    text = get_chat_response(input_text)
    
    ssml_text = get_ssml_text(text)
    message =  {
            'contentType': 'SSML',
            'content': ssml_text
        }
    fulfillment_state = "Fulfilled"    
    return close(intent_request, session_attributes, fulfillment_state, message) 

def Claude3Search_AWS_PlainText(intent_request):
    session_attributes = get_session_attributes(intent_request)
    input_text = get_prompt(intent_request)
    input_text_lower = input_text.lower()
    text = get_chat_response_3(input_text)
    
    message =  {
            'contentType': 'PlainText',
            'content': text
        }
    fulfillment_state = "Fulfilled"    
    return close(intent_request, session_attributes, fulfillment_state, message)
    
def get_prompt(intent_request):
    prompt = intent_request["inputTranscript"]
    lan = intent_request["bot"]['localeId']
           
    return prompt
    
def get_session_attributes(intent_request):
    sessionState = intent_request['sessionState']
    if 'sessionAttributes' in sessionState:
        return sessionState['sessionAttributes']

    return {}

def close(intent_request, session_attributes, fulfillment_state, message):
    intent_request['sessionState']['intent']['state'] = fulfillment_state
    return {
        'sessionState': {
            'sessionAttributes': session_attributes,
            'dialogAction': {
                'type': 'Close'
            },
            'intent': intent_request['sessionState']['intent']
        },
        'messages': [message],
        'sessionId': intent_request['sessionId'],
        'requestAttributes': intent_request['requestAttributes'] if 'requestAttributes' in intent_request else None
    }
    
def dispatch(intent_request):

    intent_name = intent_request['sessionState']['intent']['name']
    # Dispatch to your bot's intent handlers
    if intent_name == 'FallbackIntent':
        return Claude3Search_AWS_PlainText(intent_request)
    
    raise Exception('Intent with name ' + intent_name + ' not supported')
        
def lambda_handler(event, context):
    print(event)
    # TODO implement
    if 'Details' in event:
        return None
    response = dispatch(event)
    return response